﻿using ProjectKelompok2.Theme;
using ProjectKelompok2.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.Module
{
    public partial class CategoryModule : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        Category category;
        public CategoryModule(Category cat)
        {
            InitializeComponent();
            LoadTheme();
            category = cat;
            cn = new SqlConnection(con.myConnection());
            IdOtomatis();
        }
        private void LoadTheme()
        {
            panelJudul.BackColor = ThemeColor.PrimaryColor;
            labelProduk.ForeColor = Color.White;
        }
        public void IdOtomatis()
        {
            long hitung;
            string urutan;
            cn.Open();
            command = new SqlCommand("SELECT idcat FROM tbCategory WHERE idcat IN(SELECT MAX(idcat) FROM tbCategory)", cn);
            dr = command.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                hitung = Convert.ToInt64(dr[0].ToString().Substring(dr["idcat"].ToString().Length - 3, 3)) + 1;
                string joinstr = "000" + hitung;
                urutan = "CAT" + joinstr.Substring(joinstr.Length - 3, 3);
            }
            else
            {
                urutan = "CAT001";
            }
            dr.Close();
            idCat.Text = urutan;
            cn.Close();
        }
        public void Clear()
        {
            idCat.Clear();
            namCat.Clear();
            Save.Enabled = true;
            update.Enabled = false;
            IdOtomatis();
        }
        #region button
        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Apakah Ingin Disimpan?", "Save Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    command = new SqlCommand("INSERT INTO tbCategory(idcat,nama) VALUES(@idcat,@nama)", cn);
                    command.Parameters.AddWithValue("@idcat", idCat.Text);
                    command.Parameters.AddWithValue("@nama", namCat.Text);
                    cn.Open();
                    command.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Berhasil Ditambahkan");
                    Clear();
                    category.LoadDataCategory();
                    IdOtomatis();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        private void Update_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();
                command = new SqlCommand("UPDATE tbCategory SET nama = @nama WHERE idcat LIKE '" + idCat.Text + "'", cn);
                command.Parameters.AddWithValue("@nama", namCat.Text);
                command.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Berhasil Diperbarui", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                this.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Cancel_Click(object sender, EventArgs e)
        {
            Clear();
        }
        #endregion button
    }
}
