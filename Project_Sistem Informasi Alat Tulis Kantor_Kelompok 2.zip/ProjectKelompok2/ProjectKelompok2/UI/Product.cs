﻿using ProjectKelompok2.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class Product : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        public Product()
        {
            InitializeComponent();
            LoadTheme();
            cn = new SqlConnection(con.myConnection());
            LoadDataProduct();
        }
        private void LoadTheme()
        {
            dataProduct.Font = new Font("Century Gothic", 9f);
        }
        public void LoadDataProduct()
        {
            int i = 0;
            dataProduct.Rows.Clear();
            cn.Open();
            cmd = new SqlCommand("SELECT p.idpd, p.nama, c.nama, p.harga, p.jumlah FROM tbBarang AS p INNER JOIN tbCategory AS c ON c.idcat = p.cid WHERE CONCAT(p.nama, c.nama) LIKE '%" + txtSearch.Text + "%'", cn);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataProduct.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void Add_Click(object sender, EventArgs e)
        {
            ProductModule productModule = new ProductModule(this);
            productModule.update.Enabled = false;
            productModule.ShowDialog();
        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadDataProduct();
        }
        private void dataProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataProduct.Columns[e.ColumnIndex].Name;
            if (colName == "Delete")
            {
                if (MessageBox.Show("Yakin Hapus Data Ini?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cmd = new SqlCommand("DELETE FROM tbBarang WHERE idpd LIKE '" + dataProduct[1, e.RowIndex].Value.ToString() + "'", cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Data Berhasil Dihapus", "INFORMASI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (colName == "Edit")
            {
                ProductModule produkModul = new ProductModule(this);
                produkModul.Save.Enabled = false;
                produkModul.idPrdk.Text = dataProduct.Rows[e.RowIndex].Cells[1].Value.ToString();
                produkModul.namPrdk.Text = dataProduct.Rows[e.RowIndex].Cells[2].Value.ToString();
                produkModul.comCat.Text = dataProduct.Rows[e.RowIndex].Cells[3].Value.ToString();
                produkModul.harPrdk.Text = dataProduct.Rows[e.RowIndex].Cells[4].Value.ToString();
                produkModul.ShowDialog();
            }
            LoadDataProduct();
        }
        private void ExportExcell(DataGridView dataGrid, string filename)
        {
            string Output = "";
            string Headers = "";

            for (int i = 0; i < dataGrid.Columns.Count; i++)
            {
                string Line = "";
                Headers = Line.ToString() + Convert.ToString(dataGrid.Columns[i].HeaderText) + "\t";

            }
            Output += Headers + "\r\n";

            for (int i = 0; i < dataGrid.RowCount - 1; i++)
            {
                string Line = "";
                for (int j = 0; j < dataGrid.Rows[i].Cells.Count; j++)
                {
                    Line = Line.ToString() + Convert.ToString(dataGrid.Rows[i].Cells[j].Value) + "\t";

                }
                Output += Line + "\r\n";
            }
            Encoding encoding = Encoding.GetEncoding(1254);
            byte[] Outputs = encoding.GetBytes(Output);
            FileStream file = new FileStream(filename, FileMode.Create);
            BinaryWriter binary = new BinaryWriter(file);

            binary.Write(Outputs, 0, Output.Length);
            binary.Flush();
            binary.Close();
            file.Close();
        }
        private void Excel_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Excel Documents (*.xls) |*.xls";
            save.FileName = "Data Product.xls";
            if (save.ShowDialog() == DialogResult.OK)
            {
                ExportExcell(dataProduct, save.FileName);
            }
        }
    }
}
