﻿namespace ProjectKelompok2.UI
{
    partial class Cashier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cashier));
            this.Exit = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblTimer = new System.Windows.Forms.Label();
            this.panelSisi8 = new System.Windows.Forms.Panel();
            this.clrChart = new System.Windows.Forms.Button();
            this.panelSisi4 = new System.Windows.Forms.Panel();
            this.payMent = new System.Windows.Forms.Button();
            this.panelSisi5 = new System.Windows.Forms.Panel();
            this.adDisc = new System.Windows.Forms.Button();
            this.panelSisi6 = new System.Windows.Forms.Panel();
            this.timerWaktu = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cariPrdk = new System.Windows.Forms.Button();
            this.panelSisi7 = new System.Windows.Forms.Panel();
            this.newTrans = new System.Windows.Forms.Button();
            this.panelSisi1 = new System.Windows.Forms.Panel();
            this.panelSisi3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panelSisi2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panelNoTrans = new System.Windows.Forms.Panel();
            this.lblTransNo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblVatable = new System.Windows.Forms.Label();
            this.lblVat = new System.Windows.Forms.Label();
            this.lblDisc = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.panelTotal = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panelKanan = new System.Windows.Forms.Panel();
            this.lblDisplayTotal = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.dataCashier = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAdd = new System.Windows.Forms.DataGridViewImageColumn();
            this.colReduce = new System.Windows.Forms.DataGridViewImageColumn();
            this.Delete = new System.Windows.Forms.DataGridViewImageColumn();
            this.panelSisi2.SuspendLayout();
            this.panelNoTrans.SuspendLayout();
            this.panelTotal.SuspendLayout();
            this.panelKanan.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataCashier)).BeginInit();
            this.SuspendLayout();
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.Exit.Dock = System.Windows.Forms.DockStyle.Top;
            this.Exit.FlatAppearance.BorderSize = 0;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.ForeColor = System.Drawing.Color.White;
            this.Exit.Location = new System.Drawing.Point(8, 417);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(184, 41);
            this.Exit.TabIndex = 18;
            this.Exit.Text = "BACK";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(8, 412);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(184, 5);
            this.panel2.TabIndex = 17;
            // 
            // lblTimer
            // 
            this.lblTimer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblTimer.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblTimer.Location = new System.Drawing.Point(8, 496);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(184, 55);
            this.lblTimer.TabIndex = 16;
            this.lblTimer.Text = "00:00:00";
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelSisi8
            // 
            this.panelSisi8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSisi8.Location = new System.Drawing.Point(8, 407);
            this.panelSisi8.Name = "panelSisi8";
            this.panelSisi8.Size = new System.Drawing.Size(184, 5);
            this.panelSisi8.TabIndex = 14;
            // 
            // clrChart
            // 
            this.clrChart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.clrChart.Dock = System.Windows.Forms.DockStyle.Top;
            this.clrChart.Enabled = false;
            this.clrChart.FlatAppearance.BorderSize = 0;
            this.clrChart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clrChart.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clrChart.ForeColor = System.Drawing.Color.White;
            this.clrChart.Location = new System.Drawing.Point(8, 366);
            this.clrChart.Name = "clrChart";
            this.clrChart.Size = new System.Drawing.Size(184, 41);
            this.clrChart.TabIndex = 13;
            this.clrChart.Text = "Clear Chart";
            this.clrChart.UseVisualStyleBackColor = false;
            this.clrChart.Click += new System.EventHandler(this.clrChart_Click);
            // 
            // panelSisi4
            // 
            this.panelSisi4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSisi4.Location = new System.Drawing.Point(8, 361);
            this.panelSisi4.Name = "panelSisi4";
            this.panelSisi4.Size = new System.Drawing.Size(184, 5);
            this.panelSisi4.TabIndex = 12;
            // 
            // payMent
            // 
            this.payMent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.payMent.Dock = System.Windows.Forms.DockStyle.Top;
            this.payMent.Enabled = false;
            this.payMent.FlatAppearance.BorderSize = 0;
            this.payMent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.payMent.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payMent.ForeColor = System.Drawing.Color.White;
            this.payMent.Location = new System.Drawing.Point(8, 320);
            this.payMent.Name = "payMent";
            this.payMent.Size = new System.Drawing.Size(184, 41);
            this.payMent.TabIndex = 11;
            this.payMent.Text = "Payment";
            this.payMent.UseVisualStyleBackColor = false;
            this.payMent.Click += new System.EventHandler(this.payMent_Click);
            // 
            // panelSisi5
            // 
            this.panelSisi5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSisi5.Location = new System.Drawing.Point(8, 315);
            this.panelSisi5.Name = "panelSisi5";
            this.panelSisi5.Size = new System.Drawing.Size(184, 5);
            this.panelSisi5.TabIndex = 10;
            // 
            // adDisc
            // 
            this.adDisc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.adDisc.Dock = System.Windows.Forms.DockStyle.Top;
            this.adDisc.Enabled = false;
            this.adDisc.FlatAppearance.BorderSize = 0;
            this.adDisc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adDisc.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adDisc.ForeColor = System.Drawing.Color.White;
            this.adDisc.Location = new System.Drawing.Point(8, 274);
            this.adDisc.Name = "adDisc";
            this.adDisc.Size = new System.Drawing.Size(184, 41);
            this.adDisc.TabIndex = 9;
            this.adDisc.Text = "Add Discount";
            this.adDisc.UseVisualStyleBackColor = false;
            this.adDisc.Click += new System.EventHandler(this.adDisc_Click);
            // 
            // panelSisi6
            // 
            this.panelSisi6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSisi6.Location = new System.Drawing.Point(8, 269);
            this.panelSisi6.Name = "panelSisi6";
            this.panelSisi6.Size = new System.Drawing.Size(184, 5);
            this.panelSisi6.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(9, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "TOTAL           :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 7F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(9, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "VAT                :";
            // 
            // cariPrdk
            // 
            this.cariPrdk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.cariPrdk.Dock = System.Windows.Forms.DockStyle.Top;
            this.cariPrdk.FlatAppearance.BorderSize = 0;
            this.cariPrdk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cariPrdk.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cariPrdk.ForeColor = System.Drawing.Color.White;
            this.cariPrdk.Location = new System.Drawing.Point(8, 228);
            this.cariPrdk.Name = "cariPrdk";
            this.cariPrdk.Size = new System.Drawing.Size(184, 41);
            this.cariPrdk.TabIndex = 7;
            this.cariPrdk.Text = "Search Product";
            this.cariPrdk.UseVisualStyleBackColor = false;
            this.cariPrdk.Click += new System.EventHandler(this.cariPrdk_Click);
            // 
            // panelSisi7
            // 
            this.panelSisi7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSisi7.Location = new System.Drawing.Point(8, 223);
            this.panelSisi7.Name = "panelSisi7";
            this.panelSisi7.Size = new System.Drawing.Size(184, 5);
            this.panelSisi7.TabIndex = 6;
            // 
            // newTrans
            // 
            this.newTrans.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.newTrans.Dock = System.Windows.Forms.DockStyle.Top;
            this.newTrans.FlatAppearance.BorderSize = 0;
            this.newTrans.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newTrans.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newTrans.ForeColor = System.Drawing.Color.White;
            this.newTrans.Location = new System.Drawing.Point(8, 182);
            this.newTrans.Name = "newTrans";
            this.newTrans.Size = new System.Drawing.Size(184, 41);
            this.newTrans.TabIndex = 5;
            this.newTrans.Text = "New Transaction";
            this.newTrans.UseVisualStyleBackColor = false;
            this.newTrans.Click += new System.EventHandler(this.newTrans_Click);
            // 
            // panelSisi1
            // 
            this.panelSisi1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelSisi1.Location = new System.Drawing.Point(192, 182);
            this.panelSisi1.Name = "panelSisi1";
            this.panelSisi1.Size = new System.Drawing.Size(8, 369);
            this.panelSisi1.TabIndex = 3;
            // 
            // panelSisi3
            // 
            this.panelSisi3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSisi3.Location = new System.Drawing.Point(0, 174);
            this.panelSisi3.Name = "panelSisi3";
            this.panelSisi3.Size = new System.Drawing.Size(200, 8);
            this.panelSisi3.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 7F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(8, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "DISCOUNT      :";
            // 
            // panelSisi2
            // 
            this.panelSisi2.Controls.Add(this.panel3);
            this.panelSisi2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSisi2.Location = new System.Drawing.Point(0, 182);
            this.panelSisi2.Name = "panelSisi2";
            this.panelSisi2.Size = new System.Drawing.Size(8, 369);
            this.panelSisi2.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panel3.Location = new System.Drawing.Point(0, 66);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 8);
            this.panel3.TabIndex = 19;
            // 
            // panelNoTrans
            // 
            this.panelNoTrans.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.panelNoTrans.Controls.Add(this.lblTransNo);
            this.panelNoTrans.Controls.Add(this.label1);
            this.panelNoTrans.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelNoTrans.ForeColor = System.Drawing.Color.Gainsboro;
            this.panelNoTrans.Location = new System.Drawing.Point(0, 100);
            this.panelNoTrans.Name = "panelNoTrans";
            this.panelNoTrans.Size = new System.Drawing.Size(200, 74);
            this.panelNoTrans.TabIndex = 4;
            // 
            // lblTransNo
            // 
            this.lblTransNo.AutoSize = true;
            this.lblTransNo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransNo.Location = new System.Drawing.Point(57, 31);
            this.lblTransNo.Name = "lblTransNo";
            this.lblTransNo.Size = new System.Drawing.Size(89, 20);
            this.lblTransNo.TabIndex = 2;
            this.lblTransNo.Text = "0000000000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Transaction No.";
            // 
            // lblVatable
            // 
            this.lblVatable.Font = new System.Drawing.Font("Century Gothic", 9F);
            this.lblVatable.ForeColor = System.Drawing.Color.White;
            this.lblVatable.Location = new System.Drawing.Point(134, 70);
            this.lblVatable.Name = "lblVatable";
            this.lblVatable.Size = new System.Drawing.Size(58, 17);
            this.lblVatable.TabIndex = 9;
            this.lblVatable.Text = "0.00";
            this.lblVatable.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblVat
            // 
            this.lblVat.Font = new System.Drawing.Font("Century Gothic", 9F);
            this.lblVat.ForeColor = System.Drawing.Color.White;
            this.lblVat.Location = new System.Drawing.Point(134, 48);
            this.lblVat.Name = "lblVat";
            this.lblVat.Size = new System.Drawing.Size(58, 17);
            this.lblVat.TabIndex = 8;
            this.lblVat.Text = "0.00";
            this.lblVat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDisc
            // 
            this.lblDisc.Font = new System.Drawing.Font("Century Gothic", 9F);
            this.lblDisc.ForeColor = System.Drawing.Color.White;
            this.lblDisc.Location = new System.Drawing.Point(134, 30);
            this.lblDisc.Name = "lblDisc";
            this.lblDisc.Size = new System.Drawing.Size(58, 17);
            this.lblDisc.TabIndex = 7;
            this.lblDisc.Text = "0.00";
            this.lblDisc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotal
            // 
            this.lblTotal.Font = new System.Drawing.Font("Century Gothic", 9F);
            this.lblTotal.ForeColor = System.Drawing.Color.White;
            this.lblTotal.Location = new System.Drawing.Point(134, 8);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(58, 17);
            this.lblTotal.TabIndex = 6;
            this.lblTotal.Text = "0.00";
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panelTotal
            // 
            this.panelTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelTotal.Controls.Add(this.lblVatable);
            this.panelTotal.Controls.Add(this.lblVat);
            this.panelTotal.Controls.Add(this.lblDisc);
            this.panelTotal.Controls.Add(this.lblTotal);
            this.panelTotal.Controls.Add(this.label6);
            this.panelTotal.Controls.Add(this.label5);
            this.panelTotal.Controls.Add(this.label4);
            this.panelTotal.Controls.Add(this.label3);
            this.panelTotal.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTotal.Location = new System.Drawing.Point(0, 0);
            this.panelTotal.Name = "panelTotal";
            this.panelTotal.Size = new System.Drawing.Size(200, 100);
            this.panelTotal.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 7F);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(9, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "VATable        :";
            // 
            // panelKanan
            // 
            this.panelKanan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panelKanan.Controls.Add(this.Exit);
            this.panelKanan.Controls.Add(this.panel2);
            this.panelKanan.Controls.Add(this.lblTimer);
            this.panelKanan.Controls.Add(this.panelSisi8);
            this.panelKanan.Controls.Add(this.clrChart);
            this.panelKanan.Controls.Add(this.panelSisi4);
            this.panelKanan.Controls.Add(this.payMent);
            this.panelKanan.Controls.Add(this.panelSisi5);
            this.panelKanan.Controls.Add(this.adDisc);
            this.panelKanan.Controls.Add(this.panelSisi6);
            this.panelKanan.Controls.Add(this.cariPrdk);
            this.panelKanan.Controls.Add(this.panelSisi7);
            this.panelKanan.Controls.Add(this.newTrans);
            this.panelKanan.Controls.Add(this.panelSisi1);
            this.panelKanan.Controls.Add(this.panelSisi2);
            this.panelKanan.Controls.Add(this.panelSisi3);
            this.panelKanan.Controls.Add(this.panelNoTrans);
            this.panelKanan.Controls.Add(this.panelTotal);
            this.panelKanan.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelKanan.Location = new System.Drawing.Point(644, 66);
            this.panelKanan.Name = "panelKanan";
            this.panelKanan.Size = new System.Drawing.Size(200, 551);
            this.panelKanan.TabIndex = 9;
            // 
            // lblDisplayTotal
            // 
            this.lblDisplayTotal.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblDisplayTotal.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplayTotal.Location = new System.Drawing.Point(690, 0);
            this.lblDisplayTotal.Name = "lblDisplayTotal";
            this.lblDisplayTotal.Size = new System.Drawing.Size(154, 66);
            this.lblDisplayTotal.TabIndex = 7;
            this.lblDisplayTotal.Text = "0.00";
            this.lblDisplayTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtQty);
            this.panel1.Controls.Add(this.lblDisplayTotal);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(844, 66);
            this.panel1.TabIndex = 8;
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(341, 31);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(100, 20);
            this.txtQty.TabIndex = 8;
            this.txtQty.Text = "1";
            this.txtQty.Visible = false;
            // 
            // dataCashier
            // 
            this.dataCashier.AllowUserToAddRows = false;
            this.dataCashier.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataCashier.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataCashier.ColumnHeadersHeight = 30;
            this.dataCashier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataCashier.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column8,
            this.Column2,
            this.Column3,
            this.Column6,
            this.Column4,
            this.Column5,
            this.Column7,
            this.colAdd,
            this.colReduce,
            this.Delete});
            this.dataCashier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataCashier.EnableHeadersVisualStyles = false;
            this.dataCashier.Location = new System.Drawing.Point(0, 66);
            this.dataCashier.Name = "dataCashier";
            this.dataCashier.RowHeadersVisible = false;
            this.dataCashier.Size = new System.Drawing.Size(644, 551);
            this.dataCashier.TabIndex = 10;
            this.dataCashier.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataCashier_CellContentClick);
            this.dataCashier.SelectionChanged += new System.EventHandler(this.dataCashier_SelectionChanged);
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column1.HeaderText = "No";
            this.Column1.Name = "Column1";
            this.Column1.Width = 48;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column8.HeaderText = "ID Jual";
            this.Column8.Name = "Column8";
            this.Column8.Visible = false;
            this.Column8.Width = 72;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column2.HeaderText = "ID Barang";
            this.Column2.Name = "Column2";
            this.Column2.Width = 88;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Nama Barang";
            this.Column3.Name = "Column3";
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column6.DefaultCellStyle = dataGridViewCellStyle7;
            this.Column6.HeaderText = "Harga";
            this.Column6.Name = "Column6";
            this.Column6.Width = 67;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column4.DefaultCellStyle = dataGridViewCellStyle8;
            this.Column4.HeaderText = "Jumlah";
            this.Column4.Name = "Column4";
            this.Column4.Width = 73;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column5.DefaultCellStyle = dataGridViewCellStyle9;
            this.Column5.HeaderText = "Diskon";
            this.Column5.Name = "Column5";
            this.Column5.Width = 69;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column7.DefaultCellStyle = dataGridViewCellStyle10;
            this.Column7.HeaderText = "Total";
            this.Column7.Name = "Column7";
            this.Column7.Width = 60;
            // 
            // colAdd
            // 
            this.colAdd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colAdd.HeaderText = "";
            this.colAdd.Image = ((System.Drawing.Image)(resources.GetObject("colAdd.Image")));
            this.colAdd.Name = "colAdd";
            this.colAdd.Width = 5;
            // 
            // colReduce
            // 
            this.colReduce.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colReduce.HeaderText = "";
            this.colReduce.Name = "colReduce";
            this.colReduce.Width = 5;
            // 
            // Delete
            // 
            this.Delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Delete.HeaderText = "";
            this.Delete.Image = ((System.Drawing.Image)(resources.GetObject("Delete.Image")));
            this.Delete.Name = "Delete";
            this.Delete.Width = 5;
            // 
            // Cashier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 617);
            this.Controls.Add(this.dataCashier);
            this.Controls.Add(this.panelKanan);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Cashier";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cashier";
            this.panelSisi2.ResumeLayout(false);
            this.panelNoTrans.ResumeLayout(false);
            this.panelNoTrans.PerformLayout();
            this.panelTotal.ResumeLayout(false);
            this.panelTotal.PerformLayout();
            this.panelKanan.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataCashier)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Panel panelSisi8;
        private System.Windows.Forms.Button clrChart;
        private System.Windows.Forms.Panel panelSisi4;
        private System.Windows.Forms.Button payMent;
        private System.Windows.Forms.Panel panelSisi5;
        private System.Windows.Forms.Button adDisc;
        private System.Windows.Forms.Panel panelSisi6;
        private System.Windows.Forms.Timer timerWaktu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button cariPrdk;
        private System.Windows.Forms.Panel panelSisi7;
        private System.Windows.Forms.Button newTrans;
        private System.Windows.Forms.Panel panelSisi1;
        private System.Windows.Forms.Panel panelSisi3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panelSisi2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panelNoTrans;
        public System.Windows.Forms.Label lblTransNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblVatable;
        private System.Windows.Forms.Label lblVat;
        private System.Windows.Forms.Label lblDisc;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Panel panelTotal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panelKanan;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.DataGridView dataCashier;
        public System.Windows.Forms.Label lblDisplayTotal;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewImageColumn colAdd;
        private System.Windows.Forms.DataGridViewImageColumn colReduce;
        private System.Windows.Forms.DataGridViewImageColumn Delete;
    }
}