﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class StockIn : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        public StockIn()
        {
            InitializeComponent();
            cn = new SqlConnection(con.myConnection());
            LoadDataSupplier();
        }
        public void LoadDataSupplier()
        {
            comSup.Items.Clear();
            comSup.DataSource = con.GetTable("SELECT * FROM tbSupplier");
            comSup.DisplayMember = "nama";
            comSup.ValueMember = "idsup";
        }
        public void LoadDataStockIn()
        {
            int i = 0;
            dataStockIn.Rows.Clear();
            cn.Open();
            command = new SqlCommand("SELECT * FROM vwStockIn WHERE refno LIKE '" + Refno.Text + "' AND status LIKE 'Pending'", cn);
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataStockIn.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString());
            }
            dr.Close();
            cn.Close();
        }
        public void Clear()
        {
            Refno.Clear();
            sdate.Value = DateTime.Now;
        }
        public void GetRefno()
        {
            Random random = new Random();
            Refno.Clear();
            Refno.Text += random.Next();
        }
        private void comSup_SelectedIndexChanged(object sender, EventArgs e)
        {
            cn.Open();
            command = new SqlCommand("SELECT * FROM tbSupplier WHERE nama LIKE '" + comSup.Text + "'", cn);
            dr = command.ExecuteReader();
            dr.Read();
            if(dr.HasRows)
            {
                lblid.Text = dr["idsup"].ToString();
                alaSup.Text = dr["alamat"].ToString();
            }
            dr.Close();
            cn.Close();
        }
        private void comSup_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }
        private void linkGenerate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            GetRefno();
        }
        private void linkProduct_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ProductStockIn productStock = new ProductStockIn(this);
            productStock.ShowDialog();
        }
        private void Entry_Click(object sender, EventArgs e)
        {
            try
            {
                if(dataStockIn.Rows.Count > 0)
                {
                    if(MessageBox.Show("Save Kedalam Record?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        for(int i = 0; i < dataStockIn.Rows.Count; i++)
                        {
                            cn.Open();
                            command = new SqlCommand("UPDATE tbBarang SET jumlah = jumlah + " + int.Parse(dataStockIn.Rows[i].Cells[5].Value.ToString()) + "WHERE idpd LIKE '" + dataStockIn.Rows[i].Cells[3].Value.ToString() + "'", cn);
                            command.ExecuteNonQuery();
                            cn.Close();

                            cn.Open();
                            command = new SqlCommand("UPDATE tbStockIn SET jumlah = jumlah + " + int.Parse(dataStockIn.Rows[i].Cells[5].Value.ToString()) + ", status = 'Done' WHERE id LIKE '" + dataStockIn.Rows[i].Cells[1].Value.ToString() + "'", cn);
                            command.ExecuteNonQuery();
                            cn.Close();
                        }
                        Clear();
                        LoadDataStockIn();
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void dataStockIn_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataStockIn.Columns[e.ColumnIndex].Name;
            if (colName == "Delete")
            {
                if (MessageBox.Show("Yakin Hapus Data Ini?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    command = new SqlCommand("DELETE FROM tbStockIn WHERE id LIKE '" + dataStockIn.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                    command.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Data Berhasil Dihapus", "INFORMASI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDataStockIn();
                }
            }
        }
        private void Load_Click(object sender, EventArgs e)
        {
            int i = 0;
            dataStockRecord.Rows.Clear();
            cn.Open();
            command = new SqlCommand("SELECT * FROM vwStockIn WHERE CAST(sdate as date) BETWEEN '" + datFrom.Value.ToString("yyyyMMdd") + "' AND '" + datTo.Value.ToString("yyyyMMdd") + "' AND status LIKE 'Done'", cn);
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataStockRecord.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), DateTime.Parse(dr[5].ToString()).ToShortDateString(), dr[6].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void ExportExcell(DataGridView dataGrid, string filename)
        {
            string Output = "";
            string Headers = "";

            for (int i = 0; i < dataGrid.Columns.Count; i++)
            {
                string Line = "";
                Headers = Line.ToString() + Convert.ToString(dataGrid.Columns[i].HeaderText) + "\t";

            }
            Output += Headers + "\r\n";

            for (int i = 0; i < dataGrid.RowCount - 1; i++)
            {
                string Line = "";
                for (int j = 0; j < dataGrid.Rows[i].Cells.Count; j++)
                {
                    Line = Line.ToString() + Convert.ToString(dataGrid.Rows[i].Cells[j].Value) + "\t";

                }
                Output += Line + "\r\n";
            }
            Encoding encoding = Encoding.GetEncoding(1254);
            byte[] Outputs = encoding.GetBytes(Output);
            FileStream file = new FileStream(filename, FileMode.Create);
            BinaryWriter binary = new BinaryWriter(file);

            binary.Write(Outputs, 0, Output.Length);
            binary.Flush();
            binary.Close();
            file.Close();
        }
        private void Ex_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Excel Documents (*.xls) |*.xls";
            save.FileName = "Data Stock Record.xls";
            if (save.ShowDialog() == DialogResult.OK)
            {
                ExportExcell(dataStockRecord, save.FileName);
            }
        }
    }
}
