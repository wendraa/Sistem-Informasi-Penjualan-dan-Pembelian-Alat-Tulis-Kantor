﻿using ProjectKelompok2.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class Customer : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        public Customer()
        {
            InitializeComponent();
            LoadTheme();
            cn = new SqlConnection(con.myConnection());
            LoadDataCustomer();
        }
        public void LoadTheme()
        {
            dataCustomer.Font = new Font("Century Gothic", 9f);
        }
        public void LoadDataCustomer()
        {
            int i = 0;
            dataCustomer.Rows.Clear();
            cn.Open();
            cmd = new SqlCommand("SELECT * FROM tbCustomer", cn);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataCustomer.Rows.Add(i, dr["idcust"].ToString(), dr["nama"].ToString(), dr["Nomor"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void Add_Click(object sender, EventArgs e)
        {
            CustomerModule customerModule = new CustomerModule(this);
            customerModule.update.Enabled = false;
            customerModule.ShowDialog();
        }
        private void dataCustomer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataCustomer.Columns[e.ColumnIndex].Name;
            if (colName == "Delete")
            {
                if (MessageBox.Show("Yakin Hapus Data Ini?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cmd = new SqlCommand("DELETE FROM tbCustomer WHERE idcust LIKE '" + dataCustomer[1, e.RowIndex].Value.ToString() + "'", cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Data Berhasil Dihapus", "INFORMASI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (colName == "Edit")
            {
                CustomerModule customerModul = new CustomerModule(this);
                customerModul.Save.Enabled = false;
                customerModul.idCust.Text = dataCustomer[1, e.RowIndex].Value.ToString();
                customerModul.namCust.Text = dataCustomer[2, e.RowIndex].Value.ToString();
                customerModul.noCust.Text = dataCustomer[3, e.RowIndex].Value.ToString();
                customerModul.ShowDialog();
            }
            LoadDataCustomer();
        }
        private void ExportExcell(DataGridView dataGrid, string filename)
        {
            string Output = "";
            string Headers = "";

            for (int i = 0; i < dataGrid.Columns.Count; i++)
            {
                string Line = "";
                Headers = Line.ToString() + Convert.ToString(dataGrid.Columns[i].HeaderText) + "\t";

            }
            Output += Headers + "\r\n";

            for (int i = 0; i < dataGrid.RowCount - 1; i++)
            {
                string Line = "";
                for (int j = 0; j < dataGrid.Rows[i].Cells.Count; j++)
                {
                    Line = Line.ToString() + Convert.ToString(dataGrid.Rows[i].Cells[j].Value) + "\t";

                }
                Output += Line + "\r\n";
            }
            Encoding encoding = Encoding.GetEncoding(1254);
            byte[] Outputs = encoding.GetBytes(Output);
            FileStream file = new FileStream(filename, FileMode.Create);
            BinaryWriter binary = new BinaryWriter(file);

            binary.Write(Outputs, 0, Output.Length);
            binary.Flush();
            binary.Close();
            file.Close();
        }
        private void Excel_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Excel Documents (*.xls) |*.xls";
            save.FileName = "Data Customer.xls";
            if (save.ShowDialog() == DialogResult.OK)
            {
                ExportExcell(dataCustomer, save.FileName);
            }
        }
    }
}
