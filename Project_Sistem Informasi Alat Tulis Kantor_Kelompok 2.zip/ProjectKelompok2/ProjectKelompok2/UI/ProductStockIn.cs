﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class ProductStockIn : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        StockIn stockIn;
        public ProductStockIn(StockIn si)
        {
            InitializeComponent();
            stockIn = si;
            cn = new SqlConnection(con.myConnection());
            LoadDataProduct();
        }
        public void LoadDataProduct()
        {
            int i = 0;
            dataProduct.Rows.Clear();
            cn.Open();
            command = new SqlCommand("SELECT idpd, nama, jumlah FROM tbBarang WHERE nama LIKE '%" + txtSearch.Text + "%'", cn);
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataProduct.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void dataProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(stockIn.Refno.Text == string.Empty)
            {
                MessageBox.Show("Wajib Isi Nomor Referensi", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                stockIn.Refno.Focus();
                this.Dispose();
            }
            string colName = dataProduct.Columns[e.ColumnIndex].Name;
            if(colName == "Select")
            {
                if (MessageBox.Show("Tambahkan Barang Ini?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        cn.Open();
                        command = new SqlCommand("INSERT INTO tbStockIn (refno, idpd, sdate, supplierid) VALUES(@refno, @idpd, @sdate, @supplierid)", cn);
                        command.Parameters.AddWithValue("@refno", stockIn.Refno.Text);
                        command.Parameters.AddWithValue("@idpd", dataProduct.Rows[e.RowIndex].Cells[1].Value.ToString());
                        command.Parameters.AddWithValue("@sdate", stockIn.sdate.Value);
                        command.Parameters.AddWithValue("@supplierid", stockIn.lblid.Text);
                        command.ExecuteNonQuery();
                        cn.Close();
                        stockIn.LoadDataStockIn();
                        MessageBox.Show("Data Berhasil Ditambahkan", "INFORMASI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadDataProduct();
        }
        private void Close_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
