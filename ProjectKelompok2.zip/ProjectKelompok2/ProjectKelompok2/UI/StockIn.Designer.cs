﻿namespace ProjectKelompok2.UI
{
    partial class StockIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StockIn));
            this.panelTambah = new System.Windows.Forms.Panel();
            this.Entry = new System.Windows.Forms.Button();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.dataStockIn = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.alaSup = new System.Windows.Forms.TextBox();
            this.lblAla = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.comSup = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.linkGenerate = new System.Windows.Forms.LinkLabel();
            this.linkProduct = new System.Windows.Forms.LinkLabel();
            this.sdate = new System.Windows.Forms.DateTimePicker();
            this.Refno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panelJudul = new System.Windows.Forms.Panel();
            this.datFrom = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.dataStockRecord = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.datTo = new System.Windows.Forms.DateTimePicker();
            this.Load = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Delete = new System.Windows.Forms.DataGridViewImageColumn();
            this.panelTambah.SuspendLayout();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataStockIn)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panelJudul.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataStockRecord)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTambah
            // 
            this.panelTambah.Controls.Add(this.Entry);
            this.panelTambah.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelTambah.Location = new System.Drawing.Point(0, 350);
            this.panelTambah.Name = "panelTambah";
            this.panelTambah.Size = new System.Drawing.Size(703, 47);
            this.panelTambah.TabIndex = 8;
            // 
            // Entry
            // 
            this.Entry.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Entry.Location = new System.Drawing.Point(616, 12);
            this.Entry.Name = "Entry";
            this.Entry.Size = new System.Drawing.Size(75, 23);
            this.Entry.TabIndex = 0;
            this.Entry.Text = "Entry";
            this.Entry.UseVisualStyleBackColor = true;
            this.Entry.Click += new System.EventHandler(this.Entry_Click);
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.tabPage1);
            this.metroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTabControl1.Location = new System.Drawing.Point(0, 0);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(703, 350);
            this.metroTabControl1.TabIndex = 9;
            this.metroTabControl1.UseSelectable = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.BackColor = System.Drawing.Color.White;
            this.metroTabPage1.Controls.Add(this.dataStockIn);
            this.metroTabPage1.Controls.Add(this.panel1);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 6;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(695, 308);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Stock In";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 8;
            // 
            // dataStockIn
            // 
            this.dataStockIn.AllowUserToAddRows = false;
            this.dataStockIn.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataStockIn.ColumnHeadersHeight = 30;
            this.dataStockIn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataStockIn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column7,
            this.Column8,
            this.Column2,
            this.Column3,
            this.Column6,
            this.Column4,
            this.Column5,
            this.Delete});
            this.dataStockIn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataStockIn.EnableHeadersVisualStyles = false;
            this.dataStockIn.Location = new System.Drawing.Point(0, 116);
            this.dataStockIn.Name = "dataStockIn";
            this.dataStockIn.RowHeadersVisible = false;
            this.dataStockIn.Size = new System.Drawing.Size(695, 192);
            this.dataStockIn.TabIndex = 7;
            this.dataStockIn.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataStockIn_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.alaSup);
            this.panel1.Controls.Add(this.lblAla);
            this.panel1.Controls.Add(this.lblid);
            this.panel1.Controls.Add(this.comSup);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.linkGenerate);
            this.panel1.Controls.Add(this.linkProduct);
            this.panel1.Controls.Add(this.sdate);
            this.panel1.Controls.Add(this.Refno);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(695, 116);
            this.panel1.TabIndex = 2;
            // 
            // alaSup
            // 
            this.alaSup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.alaSup.Enabled = false;
            this.alaSup.Location = new System.Drawing.Point(506, 55);
            this.alaSup.Name = "alaSup";
            this.alaSup.Size = new System.Drawing.Size(173, 22);
            this.alaSup.TabIndex = 10;
            // 
            // lblAla
            // 
            this.lblAla.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAla.AutoSize = true;
            this.lblAla.Location = new System.Drawing.Point(409, 58);
            this.lblAla.Name = "lblAla";
            this.lblAla.Size = new System.Drawing.Size(70, 17);
            this.lblAla.TabIndex = 9;
            this.lblAla.Text = "Alamat     :";
            // 
            // lblid
            // 
            this.lblid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblid.AutoSize = true;
            this.lblid.ForeColor = System.Drawing.Color.White;
            this.lblid.Location = new System.Drawing.Point(409, 84);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(33, 17);
            this.lblid.TabIndex = 8;
            this.lblid.Text = "lblid";
            this.lblid.Visible = false;
            // 
            // comSup
            // 
            this.comSup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comSup.FormattingEnabled = true;
            this.comSup.Location = new System.Drawing.Point(506, 13);
            this.comSup.Name = "comSup";
            this.comSup.Size = new System.Drawing.Size(173, 25);
            this.comSup.TabIndex = 7;
            this.comSup.SelectedIndexChanged += new System.EventHandler(this.comSup_SelectedIndexChanged);
            this.comSup.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comSup_KeyPress);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(409, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Supplier    :";
            // 
            // linkGenerate
            // 
            this.linkGenerate.AutoSize = true;
            this.linkGenerate.LinkColor = System.Drawing.Color.DimGray;
            this.linkGenerate.Location = new System.Drawing.Point(235, 17);
            this.linkGenerate.Name = "linkGenerate";
            this.linkGenerate.Size = new System.Drawing.Size(79, 17);
            this.linkGenerate.TabIndex = 5;
            this.linkGenerate.TabStop = true;
            this.linkGenerate.Text = "[ Generate]";
            this.linkGenerate.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkGenerate_LinkClicked);
            // 
            // linkProduct
            // 
            this.linkProduct.AutoSize = true;
            this.linkProduct.LinkColor = System.Drawing.Color.DarkGray;
            this.linkProduct.Location = new System.Drawing.Point(123, 84);
            this.linkProduct.Name = "linkProduct";
            this.linkProduct.Size = new System.Drawing.Size(110, 17);
            this.linkProduct.TabIndex = 4;
            this.linkProduct.TabStop = true;
            this.linkProduct.Text = "[Browse Product]";
            this.linkProduct.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkProduct_LinkClicked);
            // 
            // sdate
            // 
            this.sdate.Location = new System.Drawing.Point(126, 55);
            this.sdate.Name = "sdate";
            this.sdate.Size = new System.Drawing.Size(188, 22);
            this.sdate.TabIndex = 3;
            // 
            // Refno
            // 
            this.Refno.Location = new System.Drawing.Point(126, 14);
            this.Refno.Name = "Refno";
            this.Refno.Size = new System.Drawing.Size(103, 22);
            this.Refno.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Stock In Date     :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Reference No    :";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataStockRecord);
            this.tabPage1.Controls.Add(this.panelJudul);
            this.tabPage1.Location = new System.Drawing.Point(4, 38);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(695, 308);
            this.tabPage1.TabIndex = 1;
            this.tabPage1.Text = "Record Stock";
            // 
            // panelJudul
            // 
            this.panelJudul.BackColor = System.Drawing.Color.White;
            this.panelJudul.Controls.Add(this.Load);
            this.panelJudul.Controls.Add(this.datTo);
            this.panelJudul.Controls.Add(this.label4);
            this.panelJudul.Controls.Add(this.datFrom);
            this.panelJudul.Controls.Add(this.label7);
            this.panelJudul.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelJudul.Location = new System.Drawing.Point(0, 0);
            this.panelJudul.Name = "panelJudul";
            this.panelJudul.Size = new System.Drawing.Size(695, 67);
            this.panelJudul.TabIndex = 3;
            // 
            // datFrom
            // 
            this.datFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datFrom.Location = new System.Drawing.Point(145, 18);
            this.datFrom.Name = "datFrom";
            this.datFrom.Size = new System.Drawing.Size(111, 22);
            this.datFrom.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 17);
            this.label7.TabIndex = 1;
            this.label7.Text = "Filter By Date   : From";
            // 
            // dataStockRecord
            // 
            this.dataStockRecord.AllowUserToAddRows = false;
            this.dataStockRecord.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataStockRecord.ColumnHeadersHeight = 30;
            this.dataStockRecord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataStockRecord.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.dataStockRecord.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataStockRecord.EnableHeadersVisualStyles = false;
            this.dataStockRecord.Location = new System.Drawing.Point(0, 67);
            this.dataStockRecord.Name = "dataStockRecord";
            this.dataStockRecord.RowHeadersVisible = false;
            this.dataStockRecord.Size = new System.Drawing.Size(695, 241);
            this.dataStockRecord.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(263, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "To :";
            // 
            // datTo
            // 
            this.datTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datTo.Location = new System.Drawing.Point(295, 18);
            this.datTo.Name = "datTo";
            this.datTo.Size = new System.Drawing.Size(111, 22);
            this.datTo.TabIndex = 5;
            // 
            // Load
            // 
            this.Load.Location = new System.Drawing.Point(433, 18);
            this.Load.Name = "Load";
            this.Load.Size = new System.Drawing.Size(75, 23);
            this.Load.TabIndex = 6;
            this.Load.Text = "Load";
            this.Load.UseVisualStyleBackColor = true;
            this.Load.Click += new System.EventHandler(this.Load_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn1.HeaderText = "No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 48;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn2.HeaderText = "id";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Visible = false;
            this.dataGridViewTextBoxColumn2.Width = 42;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn3.HeaderText = "Reference";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 93;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn4.HeaderText = "ID Product";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 93;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.HeaderText = "Nama Product";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn6.HeaderText = "Jumlah";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 73;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn7.HeaderText = "Stock In Date";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 111;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn8.HeaderText = "Status";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 68;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column1.HeaderText = "No.";
            this.Column1.Name = "Column1";
            this.Column1.Width = 51;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column7.HeaderText = "id";
            this.Column7.Name = "Column7";
            this.Column7.Visible = false;
            this.Column7.Width = 42;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column8.HeaderText = "Reference";
            this.Column8.Name = "Column8";
            this.Column8.Width = 93;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column2.HeaderText = "ID Product";
            this.Column2.Name = "Column2";
            this.Column2.Width = 93;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Nama Product";
            this.Column3.Name = "Column3";
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column6.HeaderText = "Jumlah";
            this.Column6.Name = "Column6";
            this.Column6.Width = 73;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column4.HeaderText = "Stock In Date";
            this.Column4.Name = "Column4";
            this.Column4.Width = 111;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column5.HeaderText = "Status";
            this.Column5.Name = "Column5";
            this.Column5.Width = 68;
            // 
            // Delete
            // 
            this.Delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Delete.HeaderText = "";
            this.Delete.Image = ((System.Drawing.Image)(resources.GetObject("Delete.Image")));
            this.Delete.Name = "Delete";
            this.Delete.Width = 5;
            // 
            // StockIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 397);
            this.ControlBox = false;
            this.Controls.Add(this.metroTabControl1);
            this.Controls.Add(this.panelTambah);
            this.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "StockIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StockIn";
            this.panelTambah.ResumeLayout(false);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataStockIn)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.panelJudul.ResumeLayout(false);
            this.panelJudul.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataStockRecord)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTambah;
        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataStockIn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.LinkLabel linkGenerate;
        private System.Windows.Forms.LinkLabel linkProduct;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.ComboBox comSup;
        public System.Windows.Forms.DateTimePicker sdate;
        public System.Windows.Forms.TextBox Refno;
        public System.Windows.Forms.Label lblid;
        private System.Windows.Forms.TextBox alaSup;
        public System.Windows.Forms.Label lblAla;
        private System.Windows.Forms.Button Entry;
        private System.Windows.Forms.DataGridView dataStockRecord;
        private System.Windows.Forms.Panel panelJudul;
        private System.Windows.Forms.Button Load;
        public System.Windows.Forms.DateTimePicker datTo;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.DateTimePicker datFrom;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewImageColumn Delete;
    }
}