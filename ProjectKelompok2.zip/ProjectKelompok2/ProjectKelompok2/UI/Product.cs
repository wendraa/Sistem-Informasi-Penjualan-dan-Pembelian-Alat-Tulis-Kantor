﻿using ProjectKelompok2.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class Product : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        public Product()
        {
            InitializeComponent();
            LoadTheme();
            cn = new SqlConnection(con.myConnection());
            LoadDataProduct();
        }
        private void LoadTheme()
        {
            dataProduct.Font = new Font("Century Gothic", 9f);
        }
        public void LoadDataProduct()
        {
            int i = 0;
            dataProduct.Rows.Clear();
            cn.Open();
            cmd = new SqlCommand("SELECT p.idpd, p.nama, c.nama, p.harga, p.jumlah FROM tbBarang AS p INNER JOIN tbCategory AS c ON c.idcat = p.cid WHERE CONCAT(p.nama, c.nama) LIKE '%" + txtSearch.Text + "%'", cn);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataProduct.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void Add_Click(object sender, EventArgs e)
        {
            ProductModule productModule = new ProductModule(this);
            productModule.update.Enabled = false;
            productModule.ShowDialog();
        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadDataProduct();
        }
    }
}
