﻿using ProjectKelompok2.Theme;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class DailySales : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;

        public DailySales()
        {
            InitializeComponent();
            cn = new SqlConnection(con.myConnection());
            LoadSold();
        }
        public void LoadTheme()
        {
            panelJudul.BackColor = ThemeColor.SecondaryColor;
            labelDailySales.ForeColor = Color.White;
        }
        public void LoadSold()
        {
            int i = 0;
            dataSoldItems.Rows.Clear();
            cn.Open();
            command = new SqlCommand("SELECT c.id, c.noTrans, c.idpd, p.nama, c.harga, c.jumlah, c.disc, c.total FROM tbPenjualan AS c INNER JOIN tbBarang AS p ON c.idpd = p.idpd WHERE status LIKE 'Sold' AND sdate BETWEEN '"+ datFrom.Value.ToString("yyyy-MM-dd") + "' AND '" + datTo.Value.ToString("yyyy-MM-dd") + "'", cn);
            dr = command.ExecuteReader();
            while(dr.Read())
            {
                i++;
                dataSoldItems.Rows.Add(i, dr["id"].ToString(), dr["noTrans"].ToString(), dr["idpd"].ToString(), dr["nama"].ToString(), dr["harga"].ToString(), dr["jumlah"].ToString(), dr["disc"].ToString(), dr["total"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void datFrom_ValueChanged(object sender, EventArgs e)
        {
            LoadSold();
        }
        private void datTo_ValueChanged(object sender, EventArgs e)
        {
            LoadSold();
        }
    }
}
