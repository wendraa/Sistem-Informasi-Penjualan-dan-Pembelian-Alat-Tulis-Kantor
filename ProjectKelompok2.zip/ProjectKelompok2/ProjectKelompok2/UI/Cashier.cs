﻿using ProjectKelompok2.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class Cashier : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;

        string id;
        string harga;
        public Cashier()
        {
            InitializeComponent();
            cn = new SqlConnection(con.myConnection());
        }
        public void LoadDataPenjualan()
        {
            Boolean hascart = false;
            int i = 0;
            double total = 0;
            double discount = 0;
            dataCashier.Rows.Clear();
            cn.Open();
            command = new SqlCommand("SELECT c.id, c.idpd, p.nama, c.harga, c.jumlah, c.disc, c.total FROM tbPenjualan AS c INNER JOIN tbBarang AS p ON c.idpd = p.idpd WHERE c.noTrans LIKE @noTrans and c.status LIKE 'Pending'", cn);
            command.Parameters.AddWithValue("@noTrans", lblTransNo.Text);
            dr = command.ExecuteReader();
            while(dr.Read())
            {
                i++;
                total += Convert.ToDouble(dr["total"].ToString());
                discount += Convert.ToDouble(dr["disc"].ToString());
                dataCashier.Rows.Add(i, dr["id"].ToString(), dr["idpd"].ToString(), dr["nama"].ToString(), dr["harga"].ToString(), dr["jumlah"].ToString(), dr["disc"].ToString(), double.Parse(dr["total"].ToString()).ToString("#,##0.00"));
                hascart = true;
            }
            dr.Close();
            cn.Close();
            lblTotal.Text = total.ToString("#,##0.00");
            lblDisc.Text = discount.ToString("#,##0.00");
            GetTotalPenjualan();
            if(hascart)
            {
                clrChart.Enabled = true;
                payMent.Enabled = true;
                adDisc.Enabled = true;
            }
            else
            {
                clrChart.Enabled = false;
                payMent.Enabled = false;
                adDisc.Enabled = false;
            }
        }
        public void GetTotalPenjualan()
        {
            double discount = double.Parse(lblDisc.Text);
            double total = double.Parse(lblTotal.Text);
            double vat = total * 0.12;
            double vatable = total - vat;

            lblVat.Text = vat.ToString("#,##0.00");
            lblVatable.Text = vatable.ToString("#,##0.00");
            lblDisplayTotal.Text = total.ToString("#,##0.00");
        }
        public void GetnoTrans()
        {
            try
            {
                string sdate = DateTime.Now.ToString("yyyyMMdd");
                int count;
                string transno;
                cn.Open();
                command = new SqlCommand("SELECT TOP 1 noTrans FROM tbPenjualan WHERE noTrans LIKE '" + sdate + "%' ORDER BY id desc", cn);
                dr = command.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    transno = dr[0].ToString();
                    count = int.Parse(transno.Substring(8, 4));
                    lblTransNo.Text = sdate + (count + 1);
                }
                else
                {
                    transno = sdate + "1001";
                    lblTransNo.Text = transno;
                }
                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }
        private void dataCashier_SelectionChanged(object sender, EventArgs e)
        {
            int i = dataCashier.CurrentRow.Index;
            id = dataCashier[1, i].Value.ToString();
            harga = dataCashier[7, i].Value?.ToString();
        }
        private void dataCashier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataCashier.Columns[e.ColumnIndex].Name;
            if (colName == "Delete")
            {
                if (MessageBox.Show("Hapus Produk Ini?", "Remove Item", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    con.ExecuteQuery("Delete FROM tbPenjualan WHERE id LIKE'" + dataCashier.Rows[e.RowIndex].Cells[1].Value.ToString() + "'");
                    MessageBox.Show("Berhasil Dihapus", "Delete Item", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDataPenjualan();
                }
            }
            else if (colName == "colAdd")
            {
                int i = 0;
                cn.Open();
                command = new SqlCommand("SELECT SUM(jumlah) as jumlah FROM tbBarang WHERE idpd LIKE'" + dataCashier.Rows[e.RowIndex].Cells[2].Value.ToString() + "' GROUP BY idpd", cn);
                i = int.Parse(command.ExecuteScalar().ToString());
                cn.Close();
                if (int.Parse(dataCashier.Rows[e.RowIndex].Cells[5].Value.ToString()) < i)
                {
                    con.ExecuteQuery("UPDATE tbPenjualan SET jumlah = jumlah + " + int.Parse(txtQty.Text) + " WHERE noTrans LIKE '" + lblTransNo.Text + "'  AND idpd LIKE '" + dataCashier.Rows[e.RowIndex].Cells[2].Value.ToString() + "'");
                    LoadDataPenjualan();
                }
                else
                {
                    MessageBox.Show("Gagal Diproses, Sisa Stok " + i + "!", "Out of Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else if (colName == "colReduce")
            {
                int i = 0;
                cn.Open();
                command = new SqlCommand("SELECT SUM(jumlah) as jumlah FROM tbPenjualan WHERE idpd LIKE'" + dataCashier.Rows[e.RowIndex].Cells[2].Value.ToString() + "' GROUP BY idpd", cn);
                i = int.Parse(command.ExecuteScalar().ToString());
                cn.Close();
                if (i > 1)
                {
                    con.ExecuteQuery("UPDATE tbPenjualan SET jumlah = jumlah - " + int.Parse(txtQty.Text) + " WHERE noTrans LIKE '" + lblTransNo.Text + "'  AND idpd LIKE '" + dataCashier.Rows[e.RowIndex].Cells[2].Value.ToString() + "'");
                    LoadDataPenjualan();
                }
                else
                {
                    MessageBox.Show("Gagal Diproses, Sisa Stok " + i + "!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
        }
        #region button
        private void cariPrdk_Click(object sender, EventArgs e)
        {
            CariProduct cariproduct = new CariProduct(this);
            cariproduct.LoadDataProduct();
            cariproduct.ShowDialog();
        }
        private void newTrans_Click(object sender, EventArgs e)
        {
            GetnoTrans();
        }
        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void adDisc_Click(object sender, EventArgs e)
        {
            Diskon disc = new Diskon(this);
            disc.lblid.Text = id;
            disc.totalHarga.Text = harga;
            disc.ShowDialog();
        }
        private void payMent_Click(object sender, EventArgs e)
        {
            Payment pay = new Payment(this);
            pay.txtSale.Text = lblDisplayTotal.Text;
            pay.ShowDialog();
        }
        private void clrChart_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Hapus Semua Produk?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                cn.Open();
                command = new SqlCommand("DELETE FROM tbPenjualan WHERE noTrans LIKE '" + lblTransNo.Text + "'", cn);
                command.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Berhasil Dihapus", "Delete Item", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadDataPenjualan();
            }
        }
        #endregion button
    }
}
