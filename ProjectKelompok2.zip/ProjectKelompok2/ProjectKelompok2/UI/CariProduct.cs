﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class CariProduct : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        Cashier cashier;
        public CariProduct(Cashier cs)
        {
            InitializeComponent();
            cashier = cs;
            cn = new SqlConnection(con.myConnection());
            LoadDataProduct();
        }
        public void LoadDataProduct()
        {
            int i = 0;
            dataProduct.Rows.Clear();
            command = new SqlCommand("SELECT p.idpd, p.nama, c.nama, p.harga, p.jumlah FROM tbBarang AS p INNER JOIN tbCategory AS c ON c.idcat = p.cid WHERE CONCAT(p.nama, c.nama) LIKE '%" + txtSearch.Text + "%'", cn);
            cn.Open();
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataProduct.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void dataProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataProduct.Columns[e.ColumnIndex].Name;
            if (colName == "Select")
            {
                Qty qty = new Qty(cashier);
                qty.ProductDetails(dataProduct.Rows[e.RowIndex].Cells[1].Value.ToString(), double.Parse(dataProduct.Rows[e.RowIndex].Cells[4].Value.ToString()), cashier.lblTransNo.Text, int.Parse(dataProduct.Rows[e.RowIndex].Cells[5].Value.ToString()));
                qty.ShowDialog();
            }
        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadDataProduct();
        }
        private void CariProduct_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape)
            {
                this.Dispose();
            }
        }
        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
