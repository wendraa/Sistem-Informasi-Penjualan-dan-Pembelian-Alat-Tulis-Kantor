﻿using ProjectKelompok2.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class Customer : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        public Customer()
        {
            InitializeComponent();
            LoadTheme();
            cn = new SqlConnection(con.myConnection());
            LoadDataCustomer();
        }
        public void LoadTheme()
        {
            dataCustomer.Font = new Font("Century Gothic", 9f);
        }
        public void LoadDataCustomer()
        {
            int i = 0;
            dataCustomer.Rows.Clear();
            cn.Open();
            cmd = new SqlCommand("SELECT * FROM tbCustomer", cn);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataCustomer.Rows.Add(i, dr["idcust"].ToString(), dr["nama"].ToString(), dr["Nomor"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void Add_Click(object sender, EventArgs e)
        {
            CustomerModule customerModule = new CustomerModule(this);
            customerModule.update.Enabled = false;
            customerModule.ShowDialog();
        }
        private void dataCustomer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataCustomer.Columns[e.ColumnIndex].Name;
            if (colName == "Delete")
            {
                if (MessageBox.Show("Yakin Hapus Data Ini?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cmd = new SqlCommand("DELETE FROM tbCustomer WHERE idcust LIKE '" + dataCustomer[1, e.RowIndex].Value.ToString() + "'", cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Data Berhasil Dihapus", "INFORMASI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (colName == "Edit")
            {
                CustomerModule customerModul = new CustomerModule(this);
                customerModul.Save.Enabled = false;
                customerModul.idCust.Text = dataCustomer[1, e.RowIndex].Value.ToString();
                customerModul.namCust.Text = dataCustomer[2, e.RowIndex].Value.ToString();
                customerModul.noCust.Text = dataCustomer[3, e.RowIndex].Value.ToString();
                customerModul.ShowDialog();
            }
            LoadDataCustomer();
        }
    }
}
