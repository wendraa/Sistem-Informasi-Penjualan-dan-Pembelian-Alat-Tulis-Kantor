﻿using ProjectKelompok2.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class Pegawai : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        public Pegawai()
        {
            InitializeComponent();
            LoadTheme();
            cn = new SqlConnection(con.myConnection());
            LoadDataPegawai();
        }
        public void LoadDataPegawai()
        {
            int i = 0;
            dataPegawai.Rows.Clear();
            cn.Open();
            command = new SqlCommand("SELECT * FROM TbPegawai", cn);
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataPegawai.Rows.Add(i, dr["id"].ToString(), dr["nama"].ToString(), dr["posisi"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        public void LoadTheme()
        {
            dataPegawai.Font = new Font("Century Gothic", 9f);
        }
        private void Add_Click(object sender, EventArgs e)
        {
            PegawaiModule pegawaiModule = new PegawaiModule(this);
            pegawaiModule.update.Enabled = false;
            pegawaiModule.Show();
        }
        private void dataPegawai_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataPegawai.Columns[e.ColumnIndex].Name;
            if (colName == "Delete")
            {
                if (MessageBox.Show("Yakin Hapus Data Ini?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    command = new SqlCommand("DELETE FROM TbPegawai WHERE id LIKE '" + dataPegawai[1, e.RowIndex].Value.ToString() + "'", cn);
                    command.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Data Berhasil Dihapus", "INFORMASI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (colName == "Edit")
            {
                PegawaiModule pegawaiModul = new PegawaiModule(this);
                pegawaiModul.Save.Enabled = false;
                pegawaiModul.idPeg.Text = dataPegawai[1, e.RowIndex].Value.ToString();
                pegawaiModul.namPeg.Text = dataPegawai[2, e.RowIndex].Value.ToString();
                pegawaiModul.posPeg.Text = dataPegawai[3, e.RowIndex].Value.ToString();
                pegawaiModul.ShowDialog();
            }
            LoadDataPegawai();
        }
    }
}
