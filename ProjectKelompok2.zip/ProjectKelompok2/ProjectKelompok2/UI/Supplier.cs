﻿using ProjectKelompok2.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class Supplier : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        public Supplier()
        {
            InitializeComponent();
            LoadTheme();
            cn = new SqlConnection(con.myConnection());
            LoadDataSupplier();
        }
        public void LoadTheme()
        {
            dataSupplier.Font = new Font("Century Gothic", 9f);
        }
        public void LoadDataSupplier()
        {
            int i = 0;
            dataSupplier.Rows.Clear();
            cn.Open();
            cmd = new SqlCommand("SELECT * FROM tbSupplier", cn);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataSupplier.Rows.Add(i, dr["idsup"].ToString(), dr["nama"].ToString(), dr["alamat"].ToString(), dr["nomor"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void Add_Click(object sender, EventArgs e)
        {
            SupplierModule supplierModule = new SupplierModule(this);
            supplierModule.update.Enabled = false;
            supplierModule.Show();
        }
        private void dataSupplier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataSupplier.Columns[e.ColumnIndex].Name;
            if (colName == "Delete")
            {
                if (MessageBox.Show("Yakin Hapus Data Ini?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cmd = new SqlCommand("DELETE FROM tbSupplier WHERE ID LIKE '" + dataSupplier[1, e.RowIndex].Value.ToString() + "'", cn);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Data Berhasil Dihapus", "INFORMASI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (colName == "Edit")
            {
                SupplierModule supplierModul = new SupplierModule(this);
                supplierModul.Save.Enabled = false;
                supplierModul.idSup.Text = dataSupplier[1, e.RowIndex].Value.ToString();
                supplierModul.namSup.Text = dataSupplier[2, e.RowIndex].Value.ToString();
                supplierModul.alaSup.Text = dataSupplier[3, e.RowIndex].Value.ToString();
                supplierModul.noSup.Text = dataSupplier[4, e.RowIndex].Value.ToString();
                supplierModul.ShowDialog();
            }
            LoadDataSupplier();
        }
    }
}
