﻿using ProjectKelompok2.Theme;
using ProjectKelompok2.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.Module
{
    public partial class ProductModule : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataReader dr;
        Connection con = new Connection();
        Product product;
        public ProductModule(Product pd)
        {
            InitializeComponent();
            cn = new SqlConnection(con.myConnection());
            product = pd;
            LoadTheme();
            LoadCategory();
            IdOtomatis();
        }
        public void Clear()
        {
            idPrdk.Clear();
            namPrdk.Clear();
            comCat.SelectedIndex = 0;
            harPrdk.Clear();
            Save.Enabled = true;
            update.Enabled = false;
            IdOtomatis();
        }
        private void LoadCategory()
        {
            comCat.Items.Clear();
            comCat.DataSource = con.GetTable("SELECT * FROM tbCategory");
            comCat.DisplayMember = "nama";
            comCat.ValueMember = "idcat";
        }
        private void LoadTheme()
        {
            panelJudul.BackColor = ThemeColor.PrimaryColor;
            labelProduct.ForeColor = Color.White;
        }
        public void IdOtomatis()
        {
            long hitung;
            string urutan;
            cn.Open();
            command = new SqlCommand("SELECT idpd FROM tbBarang WHERE idpd IN(SELECT MAX(idpd) FROM tbBarang)", cn);
            dr = command.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                hitung = Convert.ToInt64(dr[0].ToString().Substring(dr["idpd"].ToString().Length - 3, 3)) + 1;
                string joinstr = "000" + hitung;
                urutan = "PRD" + joinstr.Substring(joinstr.Length - 3, 3);
            }
            else
            {
                urutan = "PRD001";
            }
            dr.Close();
            idPrdk.Text = urutan;
            cn.Close();
        }
        #region button
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Apakah Ingin Disimpan?", "Save Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    command = new SqlCommand("INSERT INTO tbBarang(idpd,nama,cid,harga) VALUES(@idpd,@nama,@cid,@harga)", cn);
                    command.Parameters.AddWithValue("@idpd", idPrdk.Text);
                    command.Parameters.AddWithValue("@nama", namPrdk.Text);
                    command.Parameters.AddWithValue("@cid", comCat.SelectedValue);
                    command.Parameters.AddWithValue("@harga", double.Parse(harPrdk.Text));
                    cn.Open();
                    command.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Berhasil Ditambahkan");
                    Clear();
                    product.LoadDataProduct();
                    IdOtomatis();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void update_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();
                command = new SqlCommand("UPDATE tbBarang SET nama = @nama, cid = @cid, harga = @harga WHERE idpd LIKE '" + idPrdk.Text + "'", cn);
                command.Parameters.AddWithValue("@nama", namPrdk.Text);
                command.Parameters.AddWithValue("@cid", comCat.SelectedValue);
                command.Parameters.AddWithValue("@harga", double.Parse(harPrdk.Text));
                command.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Berhasil Diperbarui", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                this.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion button
    }
}