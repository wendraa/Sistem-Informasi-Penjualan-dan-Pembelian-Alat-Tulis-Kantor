﻿using ProjectKelompok2.Theme;
using ProjectKelompok2.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.Module
{
    public partial class Payment : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        Cashier cashier;
        public Payment(Cashier cs)
        {
            InitializeComponent();
            cashier = cs;
            cn = new SqlConnection(con.myConnection());
            LoadTheme();
            this.KeyPreview = true;
        }
        private void LoadTheme()
        {
            panelJudul.BackColor = ThemeColor.PrimaryColor;
            lblPayment.ForeColor = Color.White;
        }
        private void txtCash_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double sale = double.Parse(txtSale.Text);
                double cash = double.Parse(txtCash.Text);
                double charge = cash - sale;
                txtChange.Text = charge.ToString("#,##0.00");
            }
            catch
            {
                txtChange.Text = "0.00";
            }
        }
        private void Payment_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Dispose();
            }
            else if(e.KeyCode == Keys.Enter)
            {
                Enter.PerformClick();
            }
        }
        private void Enter_Click(object sender, EventArgs e)
        {
            try
            {
                if((double.Parse(txtChange.Text) < 0 ) || (txtCash.Text.Equals("")))
                {
                    MessageBox.Show("Jumlah Tidak Mencukupi, Masukkan Jumlah Yang Benar!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    for(int i = 0; i < cashier.dataCashier.Rows.Count; i++)
                    {
                        cn.Open();
                        command = new SqlCommand("UPDATE tbBarang SET jumlah = jumlah - " + int.Parse(cashier.dataCashier.Rows[i].Cells[5].Value.ToString()) + "WHERE idpd = '" + cashier.dataCashier.Rows[i].Cells[2].Value.ToString() + "'", cn);
                        command.ExecuteNonQuery();
                        cn.Close();

                        cn.Open();
                        command = new SqlCommand("UPDATE tbPenjualan SET status = 'Sold' WHERE id = '" + cashier.dataCashier.Rows[i].Cells[1].Value.ToString() + "'", cn);
                        command.ExecuteNonQuery();
                        cn.Close();
                    }
                    MessageBox.Show("Pembayaran Berhasil", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cashier.GetnoTrans();
                    cashier.LoadDataPenjualan();
                    this.Dispose();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
