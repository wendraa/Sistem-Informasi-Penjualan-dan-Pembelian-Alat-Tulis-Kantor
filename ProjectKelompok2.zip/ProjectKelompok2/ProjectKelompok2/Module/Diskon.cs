﻿using ProjectKelompok2.Theme;
using ProjectKelompok2.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.Module
{
    public partial class Diskon : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        Cashier cashier;
        public Diskon(Cashier cr)
        {
            InitializeComponent();
            cn = new SqlConnection(con.myConnection());
            cashier = cr;
            LoadTheme();
            discount.Focus();
            this.KeyPreview = true;
        }
        private void LoadTheme()
        {
            panelJudul.BackColor = ThemeColor.PrimaryColor;
            lblDiscount.ForeColor = Color.White;
        }
        private void Diskon_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Dispose();
            }
            else if (e.KeyCode == Keys.Enter)
            {
                Save.PerformClick();
            }
        }
        private void discount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double disc = double.Parse(totalHarga.Text) * double.Parse(discount.Text) * 0.01;
                totalDisc.Text = disc.ToString("#,##0.00");
            }
            catch
            {
                totalDisc.Text = "0.00";
            }
        }
        #region button
        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Tambah Diskon?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    command = new SqlCommand("UPDATE tbPenjualan SET disc_percent = @disc_percent WHERE id = @id", cn);
                    command.Parameters.AddWithValue("@disc_percent", double.Parse(discount.Text));
                    command.Parameters.AddWithValue("@id", int.Parse(lblid.Text));
                    command.ExecuteNonQuery();
                    cn.Close();
                    cashier.LoadDataPenjualan();
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        #endregion button
    }
}
