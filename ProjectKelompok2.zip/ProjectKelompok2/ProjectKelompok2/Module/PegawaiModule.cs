﻿using ProjectKelompok2.Theme;
using ProjectKelompok2.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.Module
{
    public partial class PegawaiModule : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataReader dr;
        Connection con = new Connection();
        Pegawai pegawai;
        public PegawaiModule(Pegawai pg)
        {
            InitializeComponent();
            LoadTheme();
            pegawai = pg;
            cn = new SqlConnection(con.myConnection());
            IdOtomatis();
        }
        private void LoadTheme()
        {
            panelJudul.BackColor = ThemeColor.PrimaryColor;
            labelPegawai.ForeColor = Color.White;
            namPeg.Focus();
        }
        public void IdOtomatis()
        {
            long hitung;
            string urutan;
            cn.Open();
            command = new SqlCommand("SELECT id FROM TbPegawai WHERE id IN(SELECT MAX(ID) FROM TbPegawai)", cn);
            dr = command.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                hitung = Convert.ToInt64(dr[0].ToString().Substring(dr["id"].ToString().Length - 3, 3)) + 1;
                string joinstr = "000" + hitung;
                urutan = "PG" + joinstr.Substring(joinstr.Length - 3, 3);
            }
            else
            {
                urutan = "PG001";
            }
            dr.Close();
            idPeg.Text = urutan;
            cn.Close();
        }
        public void Clear()
        {
            idPeg.Clear();
            namPeg.Clear();
            posPeg.Clear();
            Save.Enabled = true;
            update.Enabled = false;
            IdOtomatis();
        }
        #region button
        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Apakah Ingin Disimpan?", "Save Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    command = new SqlCommand("INSERT INTO TbPegawai(id,nama,posisi) VALUES(@id,@nama,@posisi)", cn);
                    command.Parameters.AddWithValue("@id", idPeg.Text);
                    command.Parameters.AddWithValue("@nama", namPeg.Text);
                    command.Parameters.AddWithValue("@posisi", posPeg.Text);
                    cn.Open();
                    command.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Berhasil Ditambahkan");
                    Clear();
                    pegawai.LoadDataPegawai();
                    IdOtomatis();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void update_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();
                command = new SqlCommand("UPDATE TbPegawai SET Nama = @nama, Posisi = @posisi WHERE id LIKE '" + idPeg.Text + "'", cn);
                command.Parameters.AddWithValue("@nama", namPeg.Text);
                command.Parameters.AddWithValue("@posisi", posPeg.Text);
                command.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Berhasil Diperbarui", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                this.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        #endregion button
    }
}
