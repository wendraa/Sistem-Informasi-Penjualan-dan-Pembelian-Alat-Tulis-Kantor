﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectKelompok2.UI
{
    public partial class Qty : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand command = new SqlCommand();
        Connection con = new Connection();
        SqlDataReader dr;
        private string idpd;
        private double harga;
        private String noTrans;
        private int jumlah;
        Cashier cashier;
        public Qty(Cashier cr)
        {
            InitializeComponent();
            cashier = cr;
            cn = new SqlConnection(con.myConnection());
        }
        public void ProductDetails(string idpd, double harga, string noTrans, int jumlah)
        {
            this.idpd = idpd;
            this.harga = harga;
            this.noTrans = noTrans;
            this.jumlah = jumlah;
        }
        private void txtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == 13) && (txtQty.Text != string.Empty))
            {
                try
                {
                    string id = "";
                    int cart_qty = 0;
                    bool found = false;
                    cn.Open();
                    command = new SqlCommand("SELECT * FROM tbPenjualan WHERE noTrans = @noTrans AND idpd = @idpd", cn);
                    command.Parameters.AddWithValue("@noTrans", noTrans);
                    command.Parameters.AddWithValue("@idpd", idpd);
                    dr = command.ExecuteReader();
                    dr.Read();
                    if (dr.HasRows)
                    {
                        id = dr["id"].ToString();
                        cart_qty = int.Parse(dr["jumlah"].ToString());
                        found = true;
                    }
                    else found = false;
                    dr.Close();
                    cn.Close();

                    if (found)
                    {
                        if (jumlah < (int.Parse(txtQty.Text) + cart_qty))
                        {
                            MessageBox.Show("Gagal Diproses, Sisa Stok " + jumlah, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        cn.Open();
                        command = new SqlCommand("Update tbPenjualan SET jumlah = (jumlah + " + int.Parse(txtQty.Text) + ") WHERE id= '" + id + "'", cn);
                        command.ExecuteReader();
                        cn.Close();
                        cashier.LoadDataPenjualan();
                        this.Dispose();
                    }
                    else
                    {
                        if (jumlah < (int.Parse(txtQty.Text) + cart_qty))
                        {
                            MessageBox.Show("Gagal Diproses, Sisa Stok " + jumlah, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        cn.Open();
                        command = new SqlCommand("INSERT INTO tbPenjualan(noTrans, idpd, harga, jumlah, sdate) VALUES(@noTrans, @idpd, @harga, @jumlah, @sdate)", cn);
                        command.Parameters.AddWithValue("@noTrans", noTrans);
                        command.Parameters.AddWithValue("@idpd", idpd);
                        command.Parameters.AddWithValue("@harga", harga);
                        command.Parameters.AddWithValue("@jumlah", int.Parse(txtQty.Text));
                        command.Parameters.AddWithValue("@sdate", DateTime.Now);
                        command.ExecuteNonQuery();
                        cn.Close();
                        cashier.LoadDataPenjualan();
                        this.Dispose();
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
